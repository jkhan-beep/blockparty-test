extends Control

const CHARACTERS = ["Barbarian", "Knight", "Mage", "Ranger", "Rogue"]

func _ready() -> void:
	# Generate random seed
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	$Center/Menu/SeedInput.text = str(rng.randi_range(100000000000, 999999999999))
	
	# Highlight the default character button
	_update_character_buttons()

func _on_new_game_button_pressed() -> void:
	GameSettings.seed = int($Center/Menu/SeedInput.text)
	GameSettings.original_seed = GameSettings.seed
	GameSettings.current_level = 1
	get_tree().change_scene_to_file("res://Land.tscn")

func _on_character_selected(character_name: String) -> void:
	GameSettings.selected_character = character_name
	_update_character_buttons()

func _update_character_buttons() -> void:
	for name in CHARACTERS:
		var btn = $Center/Menu/CharacterInput.get_node(name)
		if GameSettings.selected_character == name:
			btn.modulate = Color(1.0, 0.85, 0.3)
		else:
			btn.modulate = Color(1, 1, 1)
