## Portal.gd
## Manages the portal's activation state.
## Call activate() once all energy cells are collected.
## Listen to `player_entered` to trigger the level transition.
extends Node3D
class_name Portal

signal player_entered

@onready var _area: Area3D = $Area3D
@onready var _mesh: MeshInstance3D = $Area3D/MeshInstance3D

func _ready() -> void:
	# Start invisible and inactive
	_mesh.visible = false
	_area.monitoring = false
	_area.body_entered.connect(_on_body_entered)

## Called by Land.gd when all energy cells have been collected.
func activate() -> void:
	_area.monitoring = true
	_mesh.visible = true

func _on_body_entered(body: Node3D) -> void:
	if body is CharacterBody3D:
		player_entered.emit()
