## WinScreen.gd
## Shown after the player completes the final level.
## Waits a few seconds then returns to the main menu.
extends Control

@export var delay_seconds: float = 5.0

func _ready() -> void:
	# Release the mouse so the cursor is visible on the menu
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	# Reset level so a new game starts fresh
	GameSettings.current_level = 1
	await get_tree().create_timer(delay_seconds).timeout
	get_tree().change_scene_to_file("res://MainMenu.tscn")
