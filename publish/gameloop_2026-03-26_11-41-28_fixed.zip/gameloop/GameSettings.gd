extends Node

var seed: int = 0
var original_seed: int = 0
var selected_character: String = "Ranger"
var current_level: int = 1

# ── Level progression constants ────────────────────────────────────────────
const TOTAL_LEVELS: int = 2 # ← adjusted so we can get to the win screen

# The world size at level 1 (smallest) and at level TOTAL_LEVELS (largest).
# Change MAX_WORLD_SIZE to scale the top-end world up or down.
const MIN_WORLD_SIZE: int = 16
const MAX_WORLD_SIZE: int = 32   # ← adjusted so the second level is small

# Energy cells start at 2 on level 1 and increase by 2 each level.
const CELLS_PER_LEVEL_INCREMENT: int = 2

# ── Helpers ────────────────────────────────────────────────────────────────

## Returns the floor width/depth for the given level (1-indexed).
## Scales linearly from MIN_WORLD_SIZE to MAX_WORLD_SIZE.
func world_size_for_level(level: int) -> int:
	if TOTAL_LEVELS <= 1:
		return MAX_WORLD_SIZE
	var t: float = float(level - 1) / float(TOTAL_LEVELS - 1)
	return int(MIN_WORLD_SIZE + t * (MAX_WORLD_SIZE - MIN_WORLD_SIZE))

## Returns how many energy cells the given level requires.
func cells_for_level(level: int) -> int:
	return level * CELLS_PER_LEVEL_INCREMENT

## True when the player has completed the final level.
func is_last_level() -> bool:
	return current_level >= TOTAL_LEVELS
