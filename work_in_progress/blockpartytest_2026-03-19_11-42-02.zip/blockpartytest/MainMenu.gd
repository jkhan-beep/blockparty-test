extends Control

const CHARACTERS = ["Barbarian", "Knight", "Mage", "Ranger", "Rogue"]

func _ready() -> void:
	# Generate a random 12-digit number when the menu loads
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	var random_seed = rng.randi_range(100000000000, 999999999999)
	$SeedInput.text = str(random_seed)
	
	# Highlight the default character button
	_update_character_buttons()

func _on_new_game_button_pressed() -> void:
	# Read whatever is in the input box and save it to our singleton
	GameSettings.seed = int($Center/Menu/SeedInput.text)
	get_tree().change_scene_to_file("res://Land.tscn")

func _on_character_selected(character_name: String) -> void:
	GameSettings.selected_character = character_name
	_update_character_buttons()

func _update_character_buttons() -> void:
	for name in CHARACTERS:
		var btn = $Center/Menu/HBoxContainer.get_node(name)
		if GameSettings.selected_character == name:
			btn.modulate = Color(1.0, 0.85, 0.3)  # gold tint = selected
		else:
			btn.modulate = Color(1, 1, 1)           # normal
