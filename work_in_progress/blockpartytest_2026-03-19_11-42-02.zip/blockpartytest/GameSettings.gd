extends Node

var seed: int
var selected_character: String = "Ranger"
